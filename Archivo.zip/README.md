# 3era ENTREGA
Entrega Coderhouse
Se trabajo con SASS, se asignaron variables, extendes, nesting y mixins. Se empleo animación, degradado y rotación usando CSS.
¡Saludos!

# ENTREGA
Entrega Coderhouse
Se editó el index.html y tienda.html, se trabajó la hoja de estilos css para desktop y mobile y se agregaron imágenes
